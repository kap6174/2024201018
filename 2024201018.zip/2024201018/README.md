Junaid Ahmed
M.Tech CSE PG1
Roll No.: 2024201018

Dependencies: You must have git bash installed if you are using Windows. For Linux and macOS, bash is installed by default.

Question 1:

Description
The awk command provided in this script filters and prints all lines from an access.log file that contain HTTP POST requests that resulted in a 404 error.

Command Overview
awk '/POST.*404/ {print}' access.log
Breakdown of the Command
/POST.*404/: This is a regular expression that matches lines containing both the string POST and 404. The .* between POST and 404 matches any characters between them on the same line.
{print}: This prints the matching lines from the access.log to the terminal




Question 2:

Description
The awk command provided in this script calculates the sum of the power levels present in a text file (power_levels.txt).

Command Overview
awk -F',' '{sum+=$4;} END{print sum;}' power_levels.txt
Breakdown of the Command
-F',': Specifies that the input file uses a comma (,) as the field delimiter.
'{sum+=$4;}': Iterates through each line of the file, adding the value in the 4th column ($4) which is the power level to the variable sum.
END{print sum;}: After processing all lines, the total sum of the 4th column is printed.
